# Daily Routine Tracker v4.0 — Focus & Smart Scheduling

Personalised routine planner and study focus timer built with HTML/CSS/JavaScript and Capacitor Android.

## Build an APK with GitHub Actions
1. Upload the contents of this ZIP to the root of a GitHub repository.
2. Ensure `.github/workflows/done.yml` is included.
3. Open **Actions** and run **Build Daily Routine Tracker APK**, or push to `main` / `master`.
4. When the workflow succeeds, open the run and download the `Daily-Routine-Tracker-APK` artifact.
5. Extract the artifact ZIP and install `app-debug.apk` on an Android device.

## Current features
- Profile setup: name, age, religion, grade, stream and subjects.
- Starter study tasks based on the selected subjects (editable by the user).
- Study dashboard, saved daily study plan and offline rule-based study tips.
- Full-screen focus timer, screen wake-lock request, optional generated rain-like ambience, and native Android AccessibilityService-based focus blocking (opt-in).
- Activity creation suggests the next available time and detects overlapping scheduled activities, offering to move the new activity to the next free slot.
- Goal setting and progress tracking, existing activity scheduling, completion/late status, calendar, weekly view, reminders and JSON backup.

## Focus blocking: explicit permission and limitations
- On Android APK, tap **Start focus session → Set up app blocking** and enable **Daily Routine Tracker Focus Blocking** in Android Accessibility settings. The user must enable this system permission manually; the app cannot grant it itself.
- While the timer is actively running, the accessibility service redirects foreground apps to Home, except essential phone/system/settings apps and this tracker. Pausing or ending the timer disables blocking.
- Android Accessibility-based blocking is a focus aid, not tamper-proof parental/device-owner kiosk mode: users can disable the permission, and behavior can vary by Android vendor. It does not read screen text or capture content. Do not enable accessibility services for apps you do not trust.
- The study coach is rule-based/offline, not a cloud generative AI service and does not require an API key.
- User data is stored locally in the app's browser storage. Export a JSON backup before clearing app data or reinstalling.
- The workflow builds a debug APK, not a production-signed release.

## v8 additions
- New Aurora/Royal/Sunset/Dark/Light themes (Settings > Theme).
- Prayer tab: offline automatic prayer times (GPS or city), 30-day table, Qibla, auto-sync to prayer reminders.
- AI tab: on-device study coach, insights, day planner, and "Plan tomorrow" (also opens when you start the Sleep activity).
- Strict focus: pins the app during the focus timer (no Accessibility permission, so Play Protect does not block it).
